# Smart Attendance SaaS

Face-based attendance platform for **colleges, offices, factories, coaching centers**, and more.

```text
backend/   → Django + Django REST Framework
frontend/  → React (Vite + TypeScript)
```

## Phase 1 (this commit)
- Multi-organization model (`education`, `corporate`, `industrial`, …)
- Custom users with roles (`org_admin`, `manager`, `member`, `reception`, …)
- APIs:
  - `GET  /api/health/`
  - `GET/POST /api/organizations/`
  - `POST /api/auth/login/`
  - `POST /api/auth/logout/`
  - `GET  /api/auth/me/`
- React home page that checks backend health

## Run locally

### Backend
```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python manage.py migrate
python scripts/seed_demo.py
python manage.py runserver 8000
```

Demo login: **admin / admin123** (Demo Office)

### Frontend
```bash
cd frontend
npm install
npm run dev
```

Open http://localhost:5173  
Health http://127.0.0.1:8000/api/health/

## Phase 2 — Login
- React login form
- Django session auth + CSRF
- Dashboard shows logged-in user + logout
- Learn notes: [`docs/LEARN_LOGIN.md`](./docs/LEARN_LOGIN.md)

Demo: **admin / admin123**
