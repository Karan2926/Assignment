"""
Learning note — Phase 2 Login
=============================

What is login?
--------------
Login checks username + password, then remembers who you are
for later requests (session cookie).

Flow in our app
---------------
1. React shows login form
2. React asks Django for CSRF cookie (security)
3. React sends username/password to POST /api/auth/login/
4. Django verifies password hash
5. Django creates a session (like a temporary ID card)
6. Browser stores session cookie
7. Later APIs ( /api/auth/me/ ) know who is logged in
8. Logout deletes the session

Why CSRF?
---------
CSRF = Cross Site Request Forgery protection.
For cookie/session login, Django requires a CSRF token on POST.
We first call GET /api/auth/csrf/ so the browser gets csrftoken.

Files touched
-------------
Backend:
- accounts/views.py  -> csrf endpoint (login already existed)
- accounts/urls.py   -> /api/auth/csrf/
- config/settings.py -> CSRF_TRUSTED_ORIGINS for React port 5173

Frontend:
- src/api.ts         -> shared API helpers (credentials + CSRF)
- src/App.tsx        -> login form + dashboard after login
- src/App.css        -> login form styles
"""
