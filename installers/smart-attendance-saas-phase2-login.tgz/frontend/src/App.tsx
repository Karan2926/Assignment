import { FormEvent, useEffect, useState } from 'react'
import './App.css'
import { API_BASE, apiGet, apiPost, type User } from './api'

type Health = {
  status: string
  service: string
  phase: number
  message: string
}

function App() {
  const [health, setHealth] = useState<Health | null>(null)
  const [healthError, setHealthError] = useState('')
  const [user, setUser] = useState<User | null>(null)
  const [username, setUsername] = useState('admin')
  const [password, setPassword] = useState('admin123')
  const [authError, setAuthError] = useState('')
  const [busy, setBusy] = useState(false)

  // 1) Check backend health
  useEffect(() => {
    let cancelled = false
    async function ping() {
      try {
        const res = await fetch(`${API_BASE}/api/health/`)
        if (!res.ok) throw new Error(`HTTP ${res.status}`)
        const data = (await res.json()) as Health
        if (!cancelled) {
          setHealth(data)
          setHealthError('')
        }
      } catch (e) {
        if (!cancelled) {
          setHealth(null)
          setHealthError(
            e instanceof Error
              ? e.message
              : 'Cannot reach backend. Start Django on port 8000.',
          )
        }
      }
    }
    ping()
    return () => {
      cancelled = true
    }
  }, [])

  // 2) If a session already exists, restore logged-in user
  useEffect(() => {
    let cancelled = false
    async function loadMe() {
      try {
        const data = await apiGet<{ user: User }>('/api/auth/me/')
        if (!cancelled) setUser(data.user)
      } catch {
        if (!cancelled) setUser(null)
      }
    }
    loadMe()
    return () => {
      cancelled = true
    }
  }, [])

  async function onLogin(e: FormEvent) {
    e.preventDefault()
    setBusy(true)
    setAuthError('')
    try {
      const data = await apiPost<{ user: User }>('/api/auth/login/', {
        username,
        password,
      })
      setAuthError('')
      setUser(data.user)
    } catch (err) {
      setUser(null)
      setAuthError(err instanceof Error ? err.message : 'Login failed')
    } finally {
      setBusy(false)
    }
  }

  async function onLogout() {
    setBusy(true)
    setAuthError('')
    try {
      await apiPost('/api/auth/logout/')
    } catch {
      // ignore server errors; local logout still happens
    } finally {
      setUser(null)
      setBusy(false)
    }
  }

  return (
    <main className="page">
      <header className="hero">
        <p className="eyebrow">Startup product · Phase 2</p>
        <h1>Smart Attendance SaaS</h1>
        <p className="lead">
          Login connects React form → Django auth API → session cookie.
        </p>
      </header>

      <section className="card">
        <h2>Backend connection</h2>
        {health && (
          <div className="ok">
            <strong>Connected</strong>
            <p>{health.message}</p>
            <code>
              {health.service} · phase {health.phase} · {health.status}
            </code>
          </div>
        )}
        {healthError && (
          <div className="bad">
            <strong>Not connected</strong>
            <p>{healthError}</p>
          </div>
        )}
      </section>

      {!user ? (
        <section className="card">
          <h2>Login</h2>
          <p className="muted">
            Demo: <code>admin</code> / <code>admin123</code>
          </p>
          <form className="login-form" onSubmit={onLogin}>
            <label>
              Username
              <input
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                autoComplete="username"
                required
              />
            </label>
            <label>
              Password
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                autoComplete="current-password"
                required
              />
            </label>
            {authError && <div className="bad">{authError}</div>}
            <button type="submit" disabled={busy || !health}>
              {busy ? 'Please wait…' : 'Sign in'}
            </button>
          </form>
        </section>
      ) : (
        <section className="card">
          <h2>Dashboard</h2>
          <div className="ok">
            <strong>Logged in as {user.username}</strong>
            <p>
              Role: <code>{user.role}</code>
              {user.organization_name
                ? ` · Org: ${user.organization_name}`
                : ' · Platform user'}
            </p>
          </div>
          <button type="button" className="secondary" onClick={onLogout} disabled={busy}>
            Log out
          </button>
          <ol className="next-list">
            <li>People directory (students / employees)</li>
            <li>Face enrollment</li>
            <li>Live camera attendance</li>
          </ol>
        </section>
      )}
    </main>
  )
}

export default App
