/**
 * Small API helper for React ↔ Django.
 *
 * credentials: 'include'  → send/receive session + CSRF cookies
 * CSRF token              → required by Django for login/logout POST
 */

const API_BASE = import.meta.env.VITE_API_BASE || 'http://127.0.0.1:8000'

export type User = {
  id: number
  username: string
  email: string
  first_name: string
  last_name: string
  role: string
  organization: number | null
  organization_name: string | null
}

function getCookie(name: string): string | null {
  const match = document.cookie
    .split(';')
    .map((c) => c.trim())
    .find((c) => c.startsWith(`${name}=`))
  return match ? decodeURIComponent(match.split('=').slice(1).join('=')) : null
}

export async function ensureCsrf(): Promise<void> {
  await fetch(`${API_BASE}/api/auth/csrf/`, {
    method: 'GET',
    credentials: 'include',
  })
}

export async function apiPost<T>(path: string, body?: unknown): Promise<T> {
  await ensureCsrf()
  const csrf = getCookie('csrftoken')
  const res = await fetch(`${API_BASE}${path}`, {
    method: 'POST',
    credentials: 'include',
    headers: {
      'Content-Type': 'application/json',
      ...(csrf ? { 'X-CSRFToken': csrf } : {}),
    },
    body: body === undefined ? undefined : JSON.stringify(body),
  })
  const data = await res.json().catch(() => ({}))
  if (!res.ok) {
    const detail =
      typeof data.detail === 'string'
        ? data.detail
        : `Request failed (${res.status})`
    throw new Error(detail)
  }
  return data as T
}

export async function apiGet<T>(path: string): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, {
    method: 'GET',
    credentials: 'include',
  })
  const data = await res.json().catch(() => ({}))
  if (!res.ok) {
    const detail =
      typeof data.detail === 'string'
        ? data.detail
        : `Request failed (${res.status})`
    throw new Error(detail)
  }
  return data as T
}

export { API_BASE }
