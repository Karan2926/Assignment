# Digital Attendance System — Mentor Package

## Project summary
College Digital Attendance using face recognition.

Teachers enroll students with guided face capture, train embeddings, and mark attendance by:
1. Live camera (desk mode)
2. Classroom group photo

Designed for real college workflow: classes, subjects, teacher assignments, role-based access, and PostgreSQL storage.

## Tech stack
| Layer | Technology |
|-------|------------|
| Frontend | HTML, CSS, JavaScript |
| Backend | Python Flask |
| Database | PostgreSQL (or SQLite for local demo) |
| Face AI | InsightFace `buffalo_l` (ArcFace-family embeddings) |
| Matching | Cosine similarity on per-student centroids |

## Quick start (local demo)
```bash
cd Digital_Attendance_System
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

unset DATABASE_URL
python3 scripts/seed_admin.py --demo
python3 app.py
```
Open: http://127.0.0.1:5001

Demo logins:
- Admin: `admin` / `admin123`
- Teacher: `teacher1` / `teacher123`

## Demo flow for mentor
1. Admin → create class/subject → assign teacher
2. Teacher → Add Student → capture faces → Train Model
3. Mark Attendance (live)
4. Classroom Photo
5. Manage Students (Edit / Delete)
6. Records / Analytics

## Important design points
- Attendance is unique per student + class + subject + day
- Face embeddings stored in DB; capture photos pruned after training
- Class-scoped recognition (match only within selected class)
- Postgres support for concurrent college use (`POSTGRES.md`)

## Package contents
Source code + docs only.
Excluded: private `.env`, student face photos, local DB files, model cache pickles.

## Student
Karan — Digital Attendance System (college project)
